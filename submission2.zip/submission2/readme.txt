Currently most of the code including the SQL is in JAVA execute query statements this will be changed but its all currently in JAVA

ALSO for the data importing thats done in java 
just run 
	javac -cp "postgresql-42.2.18.jar;." costa_project.java
	java -cp "postgresql-42.2.18.jar;." costa_project
the username is username
the password is password